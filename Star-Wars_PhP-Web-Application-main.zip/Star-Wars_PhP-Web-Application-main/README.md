# Star-Wars_PhP-Web-Application

Group Project of ICS 377 Interaction Desgin Course. 

This a PhP Web Application called Star Wars for beginners. 

Project assign roles: 
Documentation: Frank H.
Frontend: Raju K. 
Backend: Tenzin N.
